﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MvcIotDevices.Data.Models;

namespace MvcIotDevices.ViewModels
{
    public class DevicesListViewModel
    {
        public IEnumerable<IoTDevice> Devices { get; set; }
        public string CurrentCategory { get; set; }
    }
}




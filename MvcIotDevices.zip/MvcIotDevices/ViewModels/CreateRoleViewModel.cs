﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Authorization;

namespace MvcIotDevices.ViewModels
{

    [Authorize(Policy = "RequireAdministratorRole")]
    public class CreateRoleViewModel
    {
        [Required]
        [Display(Name = "Administrator")]
        
        public string RoleName { get; set; }
    }
}


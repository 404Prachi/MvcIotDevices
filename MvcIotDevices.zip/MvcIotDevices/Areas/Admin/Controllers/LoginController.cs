﻿using MvcIotDevices.Security;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MvcIotDevices.Data;
using System.Linq;
using MvcIotDevices.Data.Models;

namespace MvcIotDevices.Areas.Admin.Controllers
{
    [Area("admin")]
    [Route("admin/login")]
    public class LoginController : Controller
    {
        private MvcIotDevicesContext mvcIotDevicesContext = new MvcIotDevicesContext();
        private SecurityManager securityManager = new SecurityManager();
        public LoginController(MvcIotDevicesContext _mvcIotDevicesContext) {

            this.mvcIotDevicesContext = _mvcIotDevicesContext;

        }

        [Route("")]
        [Route("index")]
        public IActionResult Index()
        {

            
            return View();
        }

        [HttpPost]
        [Route("process")]
        public IActionResult Process(string username, string password)
        {
            //var account = mvcIotDevicesContext.Accounts.SingleOrDefault(a => a.UserName.Equals(username));
            var account = processLogin(username, password);
            if (account != null)
            {
                securityManager.SignIn(this.HttpContext, account);
                return RedirectToAction("index", "dashboard", new { area = "admin" } );
            }
            else
            {
                ViewBag.error = "Invalid Account";
                return View("Index");
            }
          
        }

        private Account processLogin(string username, string password)
        {
            var account = mvcIotDevicesContext.Accounts.SingleOrDefault(a => a.UserName.Equals(username) && a.Status == true);
            if (account != null)
            {
                if(BCrypt.Net.BCrypt.Verify(password, account.Password))
                {
                    return account;
                }

            }
            return null;
        }

        [Route("signout")]
        public IActionResult SignOut()
        {
            securityManager.SignOut(this.HttpContext);
            return RedirectToAction("index", "login", new { area = "admin" });
            
        }

        [Route("accessdenied")]
        public IActionResult AccessDenied()
        {

            return View("AccessDenied");
        }
    }
}
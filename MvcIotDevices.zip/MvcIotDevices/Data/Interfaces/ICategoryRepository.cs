﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MvcIotDevices.Data.Models;

namespace MvcIotDevices.Data.Interfaces
{
    public interface ICategoryRepository
    {
        IEnumerable<DeviceCategory> DeviceCategories { get; }
    }
}

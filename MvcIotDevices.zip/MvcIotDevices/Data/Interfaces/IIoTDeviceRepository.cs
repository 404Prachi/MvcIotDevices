﻿using MvcIotDevices.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcIotDevices.Data.Interfaces
{
    public interface IIoTDeviceRepository
    {

        IEnumerable<IoTDevice> IoTDevices { get; }
        IEnumerable<IoTDevice> PreferredIoTDevices { get; }
        IoTDevice GetIoTDeviceById(int ioTDevicesId);
    }
}

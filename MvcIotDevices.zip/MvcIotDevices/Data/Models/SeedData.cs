﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MvcIotDevices.Data;

namespace MvcIotDevices.Data.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new MvcIotDevicesContext(
                serviceProvider.GetRequiredService<
                    DbContextOptions<MvcIotDevicesContext>>()))
            {
                if (!context.DeviceCategories.Any())
                {
                    context.DeviceCategories.AddRange(DeviceCategories.Select(c => c.Value));
                }

                // Look for any IoTdevice.
                if (context.IoTDevices.Any())
                {
                    return;   // DB has been seeded
                }

                context.IoTDevices.AddRange(
                    new IoTDevice
                    {
                        Title = "When Harry Met Sally",
                        ReleaseDate = DateTime.Parse("1989-2-12"),
                        Genre = "Romantic Comedy",
                        DeviceName = "Margarita",
                        DeviceCategory = DeviceCategories["Smart Home devices"],
                        ShortDescription = "Smart Home device 1",
                        LongDescription = "Smart Home device 1.",
                        ImageUrl = "http://imgh.us/margaritaL.jpg",
                        InStock = true,
                        IsPreferredDevice = false,
                        Price = 7.99M
                    },

                    new IoTDevice
                    {
                        Title = "Ghostbusters ",
                        ReleaseDate = DateTime.Parse("1984-3-13"),
                        Genre = "Comedy",
                        DeviceName = "Smartdevice",
                        ShortDescription = "Smart Home device 2" ,
                        DeviceCategory = DeviceCategories["Smart Home devices"],
                        LongDescription = "Smart Home device 2.",
                        ImageUrl = "http://imgh.us/margaritaL.jpg",
                        InStock = true,
                        IsPreferredDevice = false,
                        Price = 8.99M
                    },

                    new IoTDevice
                    {
                        Title = "Ghostbusters 2",
                        ReleaseDate = DateTime.Parse("1986-2-23"),
                        Genre = "Comedy",
                        DeviceName = "Smartdevice",
                        ShortDescription = "Smart Home device 3",
                        DeviceCategory = DeviceCategories["Smart Home devices"],
                        LongDescription = "Smart Home device 3.",
                        ImageUrl = "http://imgh.us/margaritaL.jpg",
                        InStock = true,
                        IsPreferredDevice = false,
                        Price = 9.99M
                    },

                    new IoTDevice
                    {
                        Title = "Rio Bravo",
                        ReleaseDate = DateTime.Parse("1959-4-15"),
                        Genre = "Western",
                        DeviceName = "Smartdevice",
                        ShortDescription = "Smart Home device 4",
                        DeviceCategory = DeviceCategories["Smart Home devices"],
                        LongDescription = "Smart Home device 4.",
                        ImageUrl = "http://imgh.us/margaritaL.jpg",
                        InStock = true,
                        IsPreferredDevice = false,
                        Price = 8.99M
                    }
                );

                context.SaveChanges();
            }
        }

        private static Dictionary<string, DeviceCategory> categories;
        public static Dictionary<string, DeviceCategory> DeviceCategories
        {
            get
            {
                if (categories == null)
                {
                    var categoryList = new DeviceCategory[]
                    {
                        new DeviceCategory { DeviceCategoryName = "Smart Home devices", Description="All Smart Home devices" },
                        new DeviceCategory { DeviceCategoryName = "Smart Outdoor devices", Description="All Smart Outdoor devices" }
                    };

                    categories = new Dictionary<string, DeviceCategory>();

                    foreach (DeviceCategory category in categoryList)
                    {
                        categories.Add(category.DeviceCategoryName, category);
                    }
                }

                return categories;
            }
        }
    }
 }


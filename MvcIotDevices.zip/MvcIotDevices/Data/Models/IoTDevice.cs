﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MvcIotDevices.Data.Models
{
    public class IoTDevice
    {
        public int IoTDeviceId { get; set; }

        public string DeviceName { get; set; }

        public string ShortDescription { get; set; }
        public string LongDescription { get; set; }

        public string Title { get; set; }

        [DataType(DataType.Date)]
        public DateTime ReleaseDate { get; set; }
        public string Genre { get; set; }
        
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        public string ImageUrl { get; set; }
        public string ImageThumbnailUrl { get; set; }
        public bool IsPreferredDevice { get; set; }

        public bool InStock { get; set; }

        public int CategoryId { get; set; }

        public virtual DeviceCategory DeviceCategory { get; set; }

    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MvcIotDevices.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcIotDevices.Data.Models
{
    public class ShoppingCart
    {
        private readonly MvcIotDevicesContext _mvcIotDevicesContext;

        public string ShoppingCartId { get; set; }

        private ShoppingCart(MvcIotDevicesContext mvcIotDevicesContext)
        {
            _mvcIotDevicesContext = mvcIotDevicesContext;

        }


        public List<ShoppingCartItem> ShoppingCartItems { get; set; }

        public static ShoppingCart GetCart(IServiceProvider services)
        {
            ISession session = services.GetRequiredService<IHttpContextAccessor>()?.HttpContext.Session;

            var context = services.GetService<MvcIotDevicesContext>();
            string cartId = session.GetString("CartId") ?? Guid.NewGuid().ToString();

            session.SetString("CartId", cartId);

            return new ShoppingCart(context) { ShoppingCartId = cartId };
        }

        public void AddToCart(IoTDevice ioTDevice, int amount)
        {
            var shoppingCartItem =
                    _mvcIotDevicesContext.ShoppingCartItems.SingleOrDefault(
                        s => s.IoTDevice.IoTDeviceId == ioTDevice.IoTDeviceId && s.ShoppingCartId == ShoppingCartId);

            if (shoppingCartItem == null)
            {
                shoppingCartItem = new ShoppingCartItem
                {
                    ShoppingCartId = ShoppingCartId,
                    IoTDevice = ioTDevice,
                    Amount = 1
                };

                _mvcIotDevicesContext.ShoppingCartItems.Add(shoppingCartItem);
            }
            else
            {
                shoppingCartItem.Amount++;
            }
            _mvcIotDevicesContext.SaveChanges();
        }


        public int RemoveFromCart(IoTDevice ioTDevice)
        {
            var shoppingCartItem =
                    _mvcIotDevicesContext.ShoppingCartItems.SingleOrDefault(
                        s => s.IoTDevice.IoTDeviceId == ioTDevice.IoTDeviceId && s.ShoppingCartId == ShoppingCartId);

            var localAmount = 0;

            if (shoppingCartItem != null)
            {
                if (shoppingCartItem.Amount > 1)
                {
                    shoppingCartItem.Amount--;
                    localAmount = shoppingCartItem.Amount;
                }
                else
                {
                    _mvcIotDevicesContext.ShoppingCartItems.Remove(shoppingCartItem);
                }
            }

            _mvcIotDevicesContext.SaveChanges();

            return localAmount;
        }

        public List<ShoppingCartItem> GetShoppingCartItems()
        {
            return ShoppingCartItems ??
                   (ShoppingCartItems =
                      _mvcIotDevicesContext.ShoppingCartItems.Where(c => c.ShoppingCartId == ShoppingCartId)
                           .Include(s => s.IoTDevice)
                           .ToList());
        }

        public void ClearCart()
        {
            var cartItems = _mvcIotDevicesContext
                .ShoppingCartItems
                .Where(cart => cart.ShoppingCartId == ShoppingCartId);

            _mvcIotDevicesContext.ShoppingCartItems.RemoveRange(cartItems);

            _mvcIotDevicesContext.SaveChanges();
        }

        public decimal GetShoppingCartTotal()
        {
            var total = _mvcIotDevicesContext.ShoppingCartItems.Where(c => c.ShoppingCartId == ShoppingCartId)
                .Select(c => c.IoTDevice.Price * c.Amount).Sum();
            return total;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcIotDevices.Data.Models
{
    public class DeviceCategory
    {
        public int DeviceCategoryId { get; set; }
        public string DeviceCategoryName { get; set; }
        public string Description { get; set; }
        public List<IoTDevice> IoTDevices { get; set; }
    }
}

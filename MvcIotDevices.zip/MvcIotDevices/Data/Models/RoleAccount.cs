﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace MvcIotDevices.Data.Models
{
    
    [Table("RoleAccount")]
    public class RoleAccount
    {
        
        
        public int RoleId { get; set; }
        public int AccountId { get; set; }
        public bool Status { get; set; }

        public virtual Account Account { get; set; }
        public virtual Role Role { get; set; }
        public virtual ICollection<Role> SpecificRoles { get; set; }

        public virtual ICollection<Account> Accounts { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MvcIotDevices.Data.Models;
using MvcIotDevices.Data.Interfaces;

namespace MvcIotDevices.Data.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly MvcIotDevicesContext _mvcIotDevicesContext;
        private readonly ShoppingCart _shoppingCart;


        public OrderRepository(MvcIotDevicesContext appDbContext, ShoppingCart shoppingCart)
        {
            _mvcIotDevicesContext = appDbContext;
            _shoppingCart = shoppingCart;
        }


        public void CreateOrder(Order order)
        {
            order.OrderPlaced = DateTime.Now;

            _mvcIotDevicesContext.Orders.Add(order);

            var shoppingCartItems = _shoppingCart.ShoppingCartItems;

            foreach (var shoppingCartItem in shoppingCartItems)
            {
                var orderDetail = new OrderDetail()
                {
                    Amount = shoppingCartItem.Amount,
                    DeviceId = shoppingCartItem.IoTDevice.IoTDeviceId,
                    OrderId = order.OrderId,
                    Price = shoppingCartItem.IoTDevice.Price
                };

                _mvcIotDevicesContext.OrderDetails.Add(orderDetail);
            }

            _mvcIotDevicesContext.SaveChanges();
        }


    }
}

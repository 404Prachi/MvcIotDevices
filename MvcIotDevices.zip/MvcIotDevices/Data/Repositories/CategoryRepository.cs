﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MvcIotDevices.Data.Interfaces;
using MvcIotDevices.Data.Models;

namespace MvcIotDevices.Data.Repositories
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly MvcIotDevicesContext _mvcIotDevicesContext;
        public CategoryRepository(MvcIotDevicesContext mvcIotDevicesContext)
        {
            _mvcIotDevicesContext = mvcIotDevicesContext;
        }
        public IEnumerable<DeviceCategory> DeviceCategories => _mvcIotDevicesContext.DeviceCategories;

    }
}


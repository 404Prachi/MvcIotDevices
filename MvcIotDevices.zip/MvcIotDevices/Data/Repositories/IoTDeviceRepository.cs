﻿using Microsoft.EntityFrameworkCore;
using MvcIotDevices.Data.Interfaces;
using MvcIotDevices.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcIotDevices.Data.Repositories
{
    public class IoTDeviceRepository : IIoTDeviceRepository
    {

        private readonly MvcIotDevicesContext _mvcIotDevicesContext;
        public IoTDeviceRepository(MvcIotDevicesContext mvcIotDevicesContext)
        {
            _mvcIotDevicesContext = mvcIotDevicesContext;
        }

        public IEnumerable<IoTDevice> IoTDevices => _mvcIotDevicesContext.IoTDevices.Include(c => c.DeviceCategory);

        public IEnumerable<IoTDevice> PreferredIoTDevices => _mvcIotDevicesContext.IoTDevices.Where(p => p.IsPreferredDevice).Include(c => c.DeviceCategory);

        public IoTDevice GetIoTDeviceById(int ioTDeviceId) => _mvcIotDevicesContext.IoTDevices.FirstOrDefault(p => p.IoTDeviceId == ioTDeviceId);



    }
}

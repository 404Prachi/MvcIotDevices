﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MvcIotDevices.Data.Models;
using MvcIotDevices.ViewModels;
using MvcIotDevices.Data.Interfaces;
using MvcIotDevices.Data;
using Microsoft.AspNetCore.Authorization;

namespace MvcIotDevices.Controllers
{
    public class IoTDevicesController : Controller
    {
        private readonly MvcIotDevicesContext _context;
        private readonly IIoTDeviceRepository _deviceRepository;
        private readonly ICategoryRepository _categoryRepository;

        public IoTDevicesController(MvcIotDevicesContext context, IIoTDeviceRepository deviceRepository, ICategoryRepository categoryRepository)
        {
            _context = context;
            _deviceRepository = deviceRepository;
            _categoryRepository = categoryRepository;
        }

        // GET: IoTDevices
        [AllowAnonymous]

        public async Task<IActionResult> Index()
        {
            return View(await _context.IoTDevices.ToListAsync());
        }

        // GET: IoTDevices/Details/5
        [AllowAnonymous]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ioTDevice = await _context.IoTDevices
                .FirstOrDefaultAsync(m => m.IoTDeviceId == id);
            if (ioTDevice == null)
            {
                return NotFound();
            }

            return View(ioTDevice);
        }

        // GET: IoTDevices/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: IoTDevices/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,ReleaseDate,Genre,Price")] IoTDevice ioTDevice)
        {
            if (ModelState.IsValid)
            {
                _context.Add(ioTDevice);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(ioTDevice);
        }

        // GET: IoTDevices/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ioTDevice = await _context.IoTDevices.FindAsync(id);
            if (ioTDevice == null)
            {
                return NotFound();
            }
            return View(ioTDevice);
        }

        // POST: IoTDevices/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
       
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,ReleaseDate,Genre,Price")] IoTDevice ioTDevice)
        {
            if (id != ioTDevice.IoTDeviceId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(ioTDevice);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!IoTDeviceExists(ioTDevice.IoTDeviceId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(ioTDevice);
        }

        // GET: IoTDevices/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ioTDevice = await _context.IoTDevices
                .FirstOrDefaultAsync(m => m.IoTDeviceId == id);
            if (ioTDevice == null)
            {
                return NotFound();
            }

            return View(ioTDevice);
        }

        // POST: IoTDevices/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var ioTDevice = await _context.IoTDevices.FindAsync(id);
            _context.IoTDevices.Remove(ioTDevice);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool IoTDeviceExists(int id)
        {
            return _context.IoTDevices.Any(e => e.IoTDeviceId == id);
        }


        public ViewResult List(string category)
        {
            string _category = category;
            IEnumerable<IoTDevice> devices;
            string currentCategory = string.Empty;

            if (string.IsNullOrEmpty(category))
            {
                devices = _deviceRepository.IoTDevices.OrderBy(p => p.IoTDeviceId);
                currentCategory = "All devices";
            }
            else
            {
                if (string.Equals("HomeSmartDevices", _category, StringComparison.OrdinalIgnoreCase))
                    devices = _deviceRepository.IoTDevices.Where(p => p.DeviceCategory.DeviceCategoryName.Equals("HomeSmartDevices")).OrderBy(p => p.DeviceName);
                else
                    devices = _deviceRepository.IoTDevices.Where(p => p.DeviceCategory.DeviceCategoryName.Equals("OutdoorSmartDevices")).OrderBy(p => p.DeviceName);

                currentCategory = _category;
            }

            return View(new DevicesListViewModel
            {
                Devices = devices,
                CurrentCategory = currentCategory
            });
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MvcIotDevices.Data.Interfaces;
using MvcIotDevices.Data.Models;
using MvcIotDevices.ViewModels;

namespace MvcIotDevices.Controllers
{
    public class ShoppingCartController : Controller
    {

        private readonly IIoTDeviceRepository _iIoTDeviceRepository;
        private readonly ShoppingCart _shoppingCart;

        public ShoppingCartController(IIoTDeviceRepository iIoTDeviceRepository, ShoppingCart shoppingCart)
        {
            _iIoTDeviceRepository = iIoTDeviceRepository;
            _shoppingCart = shoppingCart;
        }

        public ViewResult Index()
        {
            var items = _shoppingCart.GetShoppingCartItems();
            _shoppingCart.ShoppingCartItems = items;

            var shoppingCartViewModel = new ShoppingCartViewModel
            {
                ShoppingCart = _shoppingCart,
                ShoppingCartTotal = _shoppingCart.GetShoppingCartTotal()
            };
            return View(shoppingCartViewModel);
        }

        public RedirectToActionResult AddToShoppingCart(int drinkId)
        {
            var selectedDrink = _iIoTDeviceRepository.IoTDevices.FirstOrDefault(p => p.IoTDeviceId == drinkId);
            if (selectedDrink != null)
            {
                _shoppingCart.AddToCart(selectedDrink, 1);
            }
            return RedirectToAction("Index");
        }

        public RedirectToActionResult RemoveFromShoppingCart(int drinkId)
        {
            var selectedDrink = _iIoTDeviceRepository.IoTDevices.FirstOrDefault(p => p.IoTDeviceId == drinkId);
            if (selectedDrink != null)
            {
                _shoppingCart.RemoveFromCart(selectedDrink);
            }
            return RedirectToAction("Index");
        }



    }
}